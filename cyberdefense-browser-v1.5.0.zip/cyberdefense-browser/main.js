const { app, BrowserWindow, session, ipcMain, net, shell } = require('electron');
const path = require('path');
const fs = require('fs');

// Enhanced logging utility
function log(message, type = 'info') {
  const timestamp = new Date().toLocaleTimeString();
  const icons = {
    'info': 'ℹ️ ',
    'success': '✅ ',
    'warn': '⚠️ ',
    'error': '❌ ',
    'debug': '🐛 ',
    'net': '🌐 ',
    'vpn': '🔒 ',
    'security': '🔍 '
  };
  const icon = icons[type] || icons['info'];
  console.log(`[${timestamp}] ${icon} ${message}`);
}

let trackerBlockingEnabled = true;
let vpnEnabled = false;
let torEnabled = false;
let fastVpnEnabled = false;
let adBlockerEnabled = true;
let dntEnabled = true;
let cookieBlockerEnabled = true;
let popupBlockerEnabled = true; // Nouveau: bloqueur de popups activé par défaut
let vpnCountry = 'France';
let vpnProxy = null;
let securityScanEnabled = true; // Nouveau: scanner de sécurité activé par défaut

function safeHostname(url) {
  try {
    return new URL(url).hostname;
  } catch (e) {
    return url;
  }
}

function notifyBlocked(hostname, kind) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('cyber-blocked', { hostname, kind });
  }
}

// Liste de proxies par pays pour le mode VPN réel app-level.
// Ces serveurs de proxy peuvent être remplacés par des endpoints privés
// ou des services VPN/proxy plus fiables si besoin.
const countryProxyMap = {
  'France': 'http=51.158.123.35:8888;https=51.158.123.35:8888',
  'États-Unis': 'http=192.241.213.154:8080;https=192.241.213.154:8080',
  'Canada': 'http=192.241.151.133:3128;https=192.241.151.133:3128',
  'Allemagne': 'http=51.158.162.18:8811;https=51.158.162.18:8811',
  'Pays-Bas': 'http=51.158.111.35:8080;https=51.158.111.35:8080',
  'Japon': 'http=45.77.35.21:8080;https=45.77.35.21:8080',
  'Singapour': 'http=162.62.88.196:8080;https=162.62.88.196:8080',
  'Brésil': 'http=45.189.115.5:3128;https=45.189.115.5:3128'
};

// Proxies ultra-rapides pour le mode VPN Rapide
// Ces serveurs sont sélectionnés pour leur faible latence et haute disponibilité
const fastProxyList = [
  'http=185.82.99.181:9091;https=185.82.99.181:9091',      // Proxy fiable européen
  'http=51.15.242.202:8888;https=51.15.242.202:8888',     // OVH Cloud - France
  'http=163.172.33.137:3128;https=163.172.33.137:3128',   // Scaleway - Paris
  'http=51.158.68.68:8811;https=51.158.68.68:8811',       // Online.net - France
  'http=51.15.56.161:8080;https=51.15.56.161:8080',       // OVH - Europe
  'http=145.239.81.69:3128;https=145.239.81.69:3128',     // OVH - UK
  'http=51.15.227.220:3128;https=51.15.227.220:3128',     // OVH - Germany
  'http=163.172.146.119:3128;https=163.172.146.119:3128', // Scaleway - Amsterdam
  'http=104.248.63.15:30588; https=104.248.63.15:30588',
// Digitalocean - Haute disponibilité
'http=134.195.101.26:1080;https=134.195.101.26:1080',
// OVH • Europe rapide
' http=167.71.5.83:3128; https=167.71.5.83:3128',
// DigitalOcean NYC
 'http=206.189.36.198:8080; https=206.189.36.198:8080',
// Digitalocean Singapore
'http=178.128.84.31:3128;https=178.128.84.31:3128'
// Digitalocean London
];

let mainWindow;

function createWindow() {
  log('🚀 Création de la fenêtre principale...', 'info');
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 1040,
    minHeight: 720,
    title: 'Cyberdéfense Browser',
    backgroundColor: '#050816',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: false,
      sandbox: false,
      webSecurity: false,
      allowRunningInsecureContent: true,
      backgroundThrottling: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  log('✅ Fenêtre créée avec succès', 'success');
  mainWindow.show();
  mainWindow.removeMenu();

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (popupBlockerEnabled) {
      log(`🚫 Popup bloqué: ${url}`, 'warn');
      return { action: 'deny' };
    }
    return { action: 'allow' };
  });

  // Gestionnaire de téléchargements réel : intercepte chaque téléchargement
  // déclenché depuis n'importe quel <iframe> de la fenêtre.
  mainWindow.webContents.session.on('will-download', (event, item, webContents) => {
    const downloadId = 'dl-' + Date.now() + '-' + Math.random().toString(36).substr(2, 6);
    const suggestedName = item.getFilename();
    const savePath = path.join(app.getPath('downloads'), suggestedName);
    item.setSavePath(savePath);

    log(`⬇️ Téléchargement démarré: ${suggestedName}`, 'info');
    sendDownloadEvent({
      type: 'started',
      id: downloadId,
      filename: suggestedName,
      totalBytes: item.getTotalBytes(),
      savePath
    });

    item.on('updated', (_e, state) => {
      if (state === 'progressing' && !item.isPaused()) {
        sendDownloadEvent({
          type: 'progress',
          id: downloadId,
          receivedBytes: item.getReceivedBytes(),
          totalBytes: item.getTotalBytes()
        });
      }
    });

    item.once('done', (_e, state) => {
      if (state === 'completed') {
        log(`✅ Téléchargement terminé: ${suggestedName}`, 'success');
        sendDownloadEvent({ type: 'done', id: downloadId, state: 'completed', savePath });
      } else {
        log(`❌ Téléchargement échoué (${state}): ${suggestedName}`, 'error');
        sendDownloadEvent({ type: 'done', id: downloadId, state, savePath });
      }
    });
  });
}

function sendDownloadEvent(payload) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('cyber-download-event', payload);
  }
}




app.whenReady().then(() => {
  log('🎯 Application en cours de démarrage...', 'info');
  createWindow();
  log('✨ Cyberdéfense Browser démarré avec succès!', 'success');

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });

  session.defaultSession.webRequest.onBeforeRequest({ urls: ['*://*/*'] }, (details, callback) => {
    const trackerPatterns = [
      'google-analytics.com',
      'googletagmanager.com',
      'doubleclick.net',
      'facebook.net',
      'facebook.com/tr',
      'connect.facebook.net',
      'ads.yahoo.com',
      'ads.twitter.com',
      'analytics.twitter.com',
      'scorecardresearch.com',
      'quantserve.com',
      'hotjar.com',
      'mixpanel.com',
      'segment.io',
      'segment.com',
      'amplitude.com',
      'fullstory.com',
      'crazyegg.com',
      'mouseflow.com',
      'clarity.ms',
      'matomo.cloud',
      'newrelic.com',
      'sentry.io',
      'bugsnag.com'
    ];

    const adPatterns = [
      'google.com/ads/',
      'pagead',
      'adservice.google',
      'ad.doubleclick.net',
      'googlesyndication.com',
      'googleadservices.com',
      'amazon-adsystem.com',
      'adnxs.com',
      'adsystem.',
      'moatads.com',
      'criteo.com',
      'criteo.net',
      'outbrain.com',
      'taboola.com',
      'media.net',
      'rubiconproject.com',
      'pubmatic.com',
      'openx.net',
      'advertising.',
      'advertisement.',
      'ads.',
      '/ads/',
      '.ads-'
    ];

    if (trackerBlockingEnabled && trackerPatterns.some((pattern) => details.url.includes(pattern))) {
      const hostname = safeHostname(details.url);
      log(`🚫 Tracker bloqué: ${hostname}`, 'warn');
      notifyBlocked(hostname, 'tracker');
      return callback({ cancel: true });
    }

    if (adBlockerEnabled && adPatterns.some((pattern) => details.url.includes(pattern))) {
      const hostname = safeHostname(details.url);
      log(`🚫 Pub bloquée: ${hostname}`, 'warn');
      notifyBlocked(hostname, 'ad');
      return callback({ cancel: true });
    }

    // Le bloc de suppression des en-têtes Cookie ne fonctionne pas ici
    // (onBeforeRequest n'expose pas `requestHeaders`). La suppression
    // doit se faire dans `onBeforeSendHeaders` (enregistré plus bas).

    callback({});
  });

  session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
    const responseHeaders = details.responseHeaders;
    // Supprimer CSP et X-Frame-Options pour permettre le rendu des pages dans l'iframe
    delete responseHeaders['Content-Security-Policy'];
    delete responseHeaders['content-security-policy'];
    delete responseHeaders['X-Frame-Options'];
    delete responseHeaders['x-frame-options'];
    delete responseHeaders['X-Content-Type-Options'];
    delete responseHeaders['x-content-type-options'];
    if (dntEnabled) {
      responseHeaders['DNT'] = ['1'];
    }
    callback({ responseHeaders });
  });

    // Enregistrer un seul gestionnaire pour supprimer les en-têtes Cookie
    session.defaultSession.webRequest.onBeforeSendHeaders({ urls: ['*://*/*'] }, (details, callback) => {
      if (cookieBlockerEnabled && details.requestHeaders && details.requestHeaders.Cookie) {
        log(`🍪 Cookie bloqué`, 'debug');
        delete details.requestHeaders.Cookie;
      }
      callback({ cancel: false, requestHeaders: details.requestHeaders });
    });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

ipcMain.handle('set-tracker-blocking', (event, enabled) => {
  trackerBlockingEnabled = enabled;
  log(`Bloqueur de trackers ${enabled ? '✅ activé' : '❌ désactivé'}`, enabled ? 'success' : 'info');
  return trackerBlockingEnabled;
});

async function applyNetworkProxy() {
  if (torEnabled) {
    try {
      await session.defaultSession.setProxy({
        mode: 'fixed_servers',
        proxyRules: 'socks5://127.0.0.1:9050'
      });
      return { success: true };
    } catch (error) {
      await session.defaultSession.setProxy({ mode: 'direct' });
      return { success: false, message: `Erreur Tor: ${error.message}` };
    }
  }

  if (fastVpnEnabled) {
    // Sélectionne un proxy rapide aléatoire pour équilibrer la charge
    const randomProxy = fastProxyList[Math.floor(Math.random() * fastProxyList.length)];
    try {
      await session.defaultSession.setProxy({
        mode: 'fixed_servers',
        proxyRules: randomProxy
      });
      return { success: true };
    } catch (error) {
      await session.defaultSession.setProxy({ mode: 'direct' });
      return { success: false, message: `Erreur VPN Rapide: ${error.message}` };
    }
  }

  if (!vpnEnabled) {
    await session.defaultSession.setProxy({ mode: 'direct' });
    return { success: true };
  }

  const proxyRules = vpnProxy || countryProxyMap[vpnCountry];
  if (!proxyRules) {
    await session.defaultSession.setProxy({ mode: 'direct' });
    return { success: false, message: 'Aucun proxy configuré pour ce pays ou proxy manuel.' };
  }

  try {
    await session.defaultSession.setProxy({
      mode: 'fixed_servers',
      proxyRules
    });
    return { success: true };
  } catch (error) {
    await session.defaultSession.setProxy({ mode: 'direct' });
    return { success: false, message: `Erreur proxy: ${error.message}` };
  }
}

// Fonction d'analyse de sécurité des sites web
async function analyzeWebsiteSecurity(url) {
  try {
    const urlObj = new URL(url);
    let score = 100;
    const issues = [];
    const strengths = [];

    // Analyse HTTPS
    if (urlObj.protocol === 'https:') {
      strengths.push('Connexion HTTPS sécurisée');
    } else {
      score -= 50;
      issues.push('Connexion non chiffrée (HTTP)');
    }

    // Vérification des headers de sécurité via une requête
    try {
      const response = await net.fetch(url, {
        method: 'HEAD',
        timeout: 5000
      });

      const headers = response.headers;

      // Content Security Policy
      if (headers.get('content-security-policy')) {
        strengths.push('Content Security Policy présente');
        score += 5;
      } else {
        issues.push('Absence de Content Security Policy');
        score -= 10;
      }

      // HSTS (HTTP Strict Transport Security)
      if (headers.get('strict-transport-security')) {
        strengths.push('HSTS activé');
        score += 10;
      } else {
        issues.push('HSTS non configuré');
        score -= 15;
      }

      // X-Frame-Options
      if (headers.get('x-frame-options')) {
        strengths.push('Protection contre le clickjacking');
        score += 5;
      } else {
        issues.push('Vulnérable au clickjacking');
        score -= 10;
      }

      // X-Content-Type-Options
      if (headers.get('x-content-type-options') === 'nosniff') {
        strengths.push('Protection MIME sniffing');
        score += 5;
      } else {
        issues.push('Vulnérable au MIME sniffing');
        score -= 5;
      }

      // Referrer Policy
      if (headers.get('referrer-policy')) {
        strengths.push('Politique de référent configurée');
        score += 5;
      } else {
        issues.push('Référent non contrôlé');
        score -= 5;
      }

    } catch (error) {
      issues.push('Impossible d\'analyser les headers de sécurité');
      score -= 20;
    }

    // Vérification contre les listes de sites malveillants (simulation)
    const maliciousDomains = ['malicious-site.com', 'phishing-example.net'];
    if (maliciousDomains.some(domain => urlObj.hostname.includes(domain))) {
      score = 0;
      issues.push('Site détecté dans les listes de sites malveillants');
    } else {
      strengths.push('Site non répertorié comme malveillant');
    }

    // Analyse du domaine
    const domainParts = urlObj.hostname.split('.');
    if (domainParts.length > 2 && domainParts[domainParts.length - 2].length <= 3) {
      // Potentiel domaine suspect (ex: site.co.uk est ok, mais site.xxx est suspect)
      if (['xxx', 'adult', 'porn', 'sex'].includes(domainParts[domainParts.length - 2])) {
        score -= 15;
        issues.push('Domaine potentiellement suspect');
      }
    }

    // Score final borné entre 0 et 100
    score = Math.max(0, Math.min(100, score));

    return {
      score,
      grade: getSecurityGrade(score),
      issues,
      strengths,
      url: urlObj.hostname
    };

  } catch (error) {
    return {
      score: 0,
      grade: 'F',
      issues: ['Erreur lors de l\'analyse'],
      strengths: [],
      url: 'unknown',
      error: error.message
    };
  }
}

function getSecurityGrade(score) {
  if (score >= 90) return 'A+';
  if (score >= 80) return 'A';
  if (score >= 70) return 'B';
  if (score >= 60) return 'C';
  if (score >= 50) return 'D';
  return 'F';
}

ipcMain.handle('set-vpn-enabled', async (event, enabled) => {
  if (enabled && torEnabled) {
    torEnabled = false;
  }
  if (enabled && fastVpnEnabled) {
    fastVpnEnabled = false;
  }
  vpnEnabled = enabled;
  const result = await applyNetworkProxy();
  if (!result.success) {
    vpnEnabled = false;
    log(`❌ Erreur VPN: ${result.message}`, 'error');
  } else {
    log(`🔒 VPN ${enabled ? '✅ activé' : '❌ désactivé'} (${vpnCountry})`, enabled ? 'success' : 'info');
  }
  return { enabled: vpnEnabled, message: result.message || null };
});

ipcMain.handle('set-vpn-country', async (event, country) => {
  vpnCountry = country;
  vpnProxy = null;
  if (!vpnEnabled) {
    return { country: vpnCountry, enabled: false };
  }

  const result = await applyNetworkProxy();
  if (!result.success) {
    vpnEnabled = false;
  }
  return { country: vpnCountry, enabled: vpnEnabled, message: result.message || null };
});

ipcMain.handle('set-vpn-proxy', async (event, proxyValue) => {
  if (torEnabled) {
    torEnabled = false;
  }
  if (fastVpnEnabled) {
    fastVpnEnabled = false;
  }
  vpnProxy = proxyValue;
  vpnEnabled = true;
  const result = await applyNetworkProxy();
  if (!result.success) {
    vpnEnabled = false;
  }
  return { enabled: vpnEnabled, message: result.message || null };
});

ipcMain.handle('set-tor-enabled', async (event, enabled) => {
  torEnabled = enabled;
  if (torEnabled) {
    vpnEnabled = false;
    fastVpnEnabled = false;
    vpnProxy = null;
  }
  const result = await applyNetworkProxy();
  if (!result.success) {
    torEnabled = false;
    log(`❌ Erreur Tor: ${result.message}`, 'error');
  } else {
    log(`🧅 Tor ${enabled ? '✅ activé' : '❌ désactivé'}`, enabled ? 'success' : 'info');
  }
  return { enabled: torEnabled, message: result.message || null };
});

ipcMain.handle('set-fast-vpn-enabled', async (event, enabled) => {
  fastVpnEnabled = enabled;
  if (fastVpnEnabled) {
    vpnEnabled = false;
    torEnabled = false;
    vpnProxy = null;
  }
  const result = await applyNetworkProxy();
  if (!result.success) {
    fastVpnEnabled = false;
    log(`❌ Erreur VPN Rapide: ${result.message}`, 'error');
  } else {
    log(`⚡ VPN Rapide ${enabled ? '✅ activé' : '❌ désactivé'}`, enabled ? 'success' : 'info');
  }
  return { enabled: fastVpnEnabled, message: result.message || null };
});

ipcMain.handle('set-ad-blocker', (event, enabled) => {
  adBlockerEnabled = enabled;
  log(`Bloqueur d'annonces ${enabled ? '✅ activé' : '❌ désactivé'}`, enabled ? 'success' : 'info');
  return { enabled: adBlockerEnabled };
});

ipcMain.handle('set-dnt', (event, enabled) => {
  dntEnabled = enabled;
  log(`Do Not Track ${enabled ? '✅ activé' : '❌ désactivé'}`, enabled ? 'success' : 'info');
  return { enabled: dntEnabled };
});

ipcMain.handle('set-cookie-blocker', (event, enabled) => {
  cookieBlockerEnabled = enabled;
  log(`Bloqueur de cookies ${enabled ? '✅ activé' : '❌ désactivé'}`, enabled ? 'success' : 'info');
  return { enabled: cookieBlockerEnabled };
});

ipcMain.handle('set-popup-blocker', (event, enabled) => {
  popupBlockerEnabled = enabled;
  return { enabled: popupBlockerEnabled };
});

ipcMain.handle('clear-browsing-data', async (event) => {
  try {
    await session.defaultSession.clearCache();
    await session.defaultSession.clearStorageData({
      storages: ['cookies', 'localStorage', 'sessionStorage', 'serviceWorkers', 'indexeddb']
    });
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

// Nouvelles fonctionnalités : Scanner de sécurité
ipcMain.handle('analyze-security', async (event, url) => {
  try {
    const securityAnalysis = await analyzeWebsiteSecurity(url);
    return securityAnalysis;
  } catch (error) {
    return { error: error.message, score: 0 };
  }
});

ipcMain.handle('set-security-scan', (event, enabled) => {
  securityScanEnabled = enabled;
  return { enabled: securityScanEnabled };
});

// Gestionnaire de cookies
ipcMain.handle('get-cookies', async (event) => {
  try {
    const cookies = await session.defaultSession.cookies.get({});
    return { cookies: cookies.slice(0, 50) };
  } catch (error) {
    return { cookies: [], error: error.message };
  }
});

// Gestionnaire de tâches pour Mode Lecture (simulation)
ipcMain.handle('enable-reader-mode', (event) => {
  return { success: true, message: 'Mode Lecture activé' };
});

// Gestionnaire de performance
ipcMain.handle('get-performance-stats', (event, stats) => {
  return {
    avgLoadTime: stats.avgLoadTime || 0,
    totalPages: stats.totalPages || 0,
    performanceGrade: stats.avgLoadTime < 1000 ? 'A' : stats.avgLoadTime < 3000 ? 'B' : 'C'
  };
});

// Ouvre le dossier système et sélectionne le fichier téléchargé
ipcMain.handle('show-download-in-folder', (event, savePath) => {
  try {
    shell.showItemInFolder(savePath);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

// Capture d'écran réelle de la fenêtre active (fonctionne même avec du
// contenu cross-origin dans les iframes, car la capture se fait au niveau
// du compositeur, pas du DOM).
ipcMain.handle('capture-screenshot', async (event) => {
  try {
    if (!mainWindow || mainWindow.isDestroyed()) {
      return { success: false, error: 'Fenêtre indisponible' };
    }
    const image = await mainWindow.webContents.capturePage();
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `cyberdefense-capture-${timestamp}.png`;
    const savePath = path.join(app.getPath('pictures'), filename);
    fs.writeFileSync(savePath, image.toPNG());
    log(`📸 Capture d'écran enregistrée: ${savePath}`, 'success');
    return { success: true, filename, savePath };
  } catch (e) {
    log(`❌ Échec de la capture d'écran: ${e.message}`, 'error');
    return { success: false, error: e.message };
  }
});
