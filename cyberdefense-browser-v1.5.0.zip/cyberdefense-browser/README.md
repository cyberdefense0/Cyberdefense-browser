# Cyberdéfense Browser

Prototype de navigateur Electron avec panneau de sécurité façon cyberpunk.

## Fonctionnalités

### Navigation
- Barre d'adresse avec suggestions (favoris + historique) en direct
- Onglets multiples avec favicon, clic droit (dupliquer, fermer les autres, fermer tout)
- Historique de navigation consultable et effaçable
- Favoris avec ajout/suppression rapide
- Page "Nouvel onglet" dédiée (`start.html`) : horloge, recherche rapide, grille de favoris
- Barre de progression de chargement en haut de la fenêtre
- Zoom par onglet (−/+, raccourcis Ctrl +/-, double-clic pour réinitialiser)
- Mode focus (masque tout sauf la page active — Échap pour quitter)
- Session restaurée automatiquement au redémarrage (onglets, thème, moteur de recherche)

### Sécurité & vie privée
- Bloqueur de trackers et de publicités, avec **liste étendue** de domaines connus (analytics, pubs, régies) et **compteur en temps réel** des éléments réellement bloqués (fini le chiffre aléatoire)
- VPN intégré (par pays ou proxy manuel), VPN Rapide, routage Tor (Onion)
- Do Not Track, bloqueur de cookies, bloqueur de popups
- Scanner de sécurité par site (HTTPS, HSTS, CSP, clickjacking, MIME sniffing…) avec score et grade
- **Réputation de domaine réelle** : calculée à partir de l'historique de sécurité du site, avec tendance ↑/↓
- Alerte automatique (toast) si un site obtient un score de sécurité faible
- Inspecteur de cookies, **moniteur de performance réel** (temps de chargement mesuré et moyenne glissante)
- **Générateur de mot de passe avancé** : longueur réglable (8-64), choix des types de caractères, indicateur de force basé sur l'entropie réelle, génération cryptographiquement sûre (`crypto.getRandomValues`), copie en un clic
- **Filtre lumière bleue / Mode nuit** : teinte chaude appliquée à la page active, intensité réglable, préférence mémorisée

### Interface
- **Capture d'écran** de la page active, enregistrée dans le dossier Images
- **Gestionnaire de téléchargements réel** : suit chaque téléchargement (progression, taille, statut), accessible depuis l'en-tête avec badge du nombre de téléchargements en cours, bouton pour ouvrir le dossier contenant le fichier
- 5 thèmes (Cyberpunk Neon, Dark, Light, Matrix Green, Sunset) qui recolorent toute l'interface
- **Mode Lecture réel** : extrait le contenu principal de la page (titre + texte), l'affiche dans une vue épurée avec réglage de la taille du texte et temps de lecture estimé
- **Tutoriel de bienvenue** au premier lancement (relançable via le bouton ❔), 5 étapes qui présentent le panneau, les onglets, le scanner et les raccourcis
- Notifications toast pour les actions importantes
- Panneau latéral redimensionnable (glisser le séparateur) et repliable
- Console de logs intégrée avec horodatage et niveaux (info/succès/avertissement/erreur)

### Raccourcis clavier
| Raccourci | Action |
|---|---|
| `Ctrl+T` | Nouvel onglet |
| `Ctrl+W` | Fermer l'onglet actif |
| `Ctrl+L` | Sélectionner la barre d'adresse |
| `Ctrl+D` | Ajouter la page aux favoris |
| `Ctrl+F` | Rechercher dans la page |
| `Ctrl+ +` / `Ctrl+ -` / `Ctrl+0` | Zoom avant / arrière / réinitialiser |
| `Ctrl+1`…`Ctrl+9` | Aller à l'onglet N |
| `Échap` | Quitter le mode focus |

## Installation

1. Ouvrez un terminal dans le dossier du projet.
2. Lancez `npm install`.
3. Lancez `npm start`.

## Notes

- Prototype de navigateur desktop — la navigation utilise des `<iframe>` (le tag `<webview>` est désactivé côté Electron).
- Le VPN utilise un routage proxy au niveau de l'application ; ce n'est pas un tunnel VPN complet.
- Améliorations possibles : détection de phishing, scan SSL avancé, outils OSINT, terminal intégré, analyse IA.
